export const API_KEY = process.env.EXPO_PUBLIC_API_KEY;
